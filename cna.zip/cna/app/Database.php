<?php
declare(strict_types=1);

/**
 * Administra una única conexión PDO con la base de datos.
 */
final class Database
{
    private static ?PDO $conexion = null;

    private function __construct()
    {
        // Esta clase solo se utiliza mediante Database::getConnection().
    }

    public static function getConnection(): PDO
    {
        if (self::$conexion === null) {
            $host = 'localhost';
            $baseDatos = 'cna';
            $usuario = 'root';
            $contrasena = '';

            $dsn = "mysql:host={$host};dbname={$baseDatos};charset=utf8mb4";

            self::$conexion = new PDO($dsn, $usuario, $contrasena, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        }

        return self::$conexion;
    }
}
