<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$esRegistro = isset($_GET['registro']);
$mensaje = '';
$tipoMensaje = 'error';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim((string) ($_POST['u'] ?? ''));
    $contrasena = (string) ($_POST['p'] ?? '');

    try {
        $modeloUsuario = new Usuario();

        if ($esRegistro) {
            $repetirContrasena = (string) ($_POST['p2'] ?? '');

            // Validaciones del usuario (2): no vacío y longitud/formato permitido.
            if ($usuario === '') {
                $mensaje = 'Escribe tu correo electrónico.';
            } elseif (strlen($usuario) > 100 || !filter_var($usuario, FILTER_VALIDATE_EMAIL) || strpos($usuario, '@') === false) {
                $mensaje = 'Ingresa un correo electrónico válido que incluya @.';
            } elseif (strlen($contrasena) < 6) {
                $mensaje = 'La contraseña debe tener al menos 6 caracteres.';
            } elseif (!preg_match('/[A-Za-z]/', $contrasena)) {
                $mensaje = 'La contraseña debe incluir al menos una letra.';
            } elseif (!preg_match('/[0-9]/', $contrasena)) {
                $mensaje = 'La contraseña debe incluir al menos un número.';
            } elseif ($contrasena !== $repetirContrasena) {
                $mensaje = 'Las contraseñas no coinciden.';
            } else {
                $modeloUsuario->registrar($usuario, $contrasena);
                header('Location: index.php?ok=1');
                exit;
            }
        } else {
            // Validaciones del inicio de sesión (2): usuario y contraseña obligatorios.
            if ($usuario === '') {
                $mensaje = 'Escribe tu correo electrónico.';
            } elseif (!filter_var($usuario, FILTER_VALIDATE_EMAIL) || strpos($usuario, '@') === false) {
                $mensaje = 'Ingresa un correo electrónico válido que incluya @.';
            } elseif ($contrasena === '') {
                $mensaje = 'Escribe tu contraseña.';
            } elseif (strlen($usuario) > 50 || strlen($contrasena) > 4096) {
                $mensaje = 'Los datos ingresados superan la longitud permitida.';
            } else {
                $datosUsuario = $modeloUsuario->login($usuario, $contrasena);

                if ($datosUsuario !== false) {
                    session_regenerate_id(true);
                    $_SESSION['u'] = $datosUsuario['correo'];
                    $_SESSION['idUsuario'] = (int) $datosUsuario['idUsuario'];
                    $_SESSION['rol'] = $datosUsuario['rol'];
                    $_SESSION['idCoord'] = (new Coordinador())->idPorUsuario(
                        (int) $datosUsuario['idUsuario']
                    );

                    header('Location: panel.php');
                    exit;
                }

                $mensaje = 'Usuario o contraseña incorrectos.';
            }
        }
    } catch (PDOException $error) {
        $mensaje = 'No se pudo completar la operación. Verifica si el usuario ya existe y revisa la conexión.';
    } catch (Throwable $error) {
        $mensaje = $error->getMessage();
    }
}

if (isset($_GET['ok'])) {
    $mensaje = 'Cuenta creada correctamente. Ya puedes iniciar sesión.';
    $tipoMensaje = 'exito';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CNA - <?= $esRegistro ? 'Crear cuenta' : 'Iniciar sesión' ?></title>
    <link rel="stylesheet" href="css/cna.css">
</head>
<body>
    <main class="contenedor">
        <div class="barra-opciones"><button type="button" id="cambiarTema">Tema oscuro</button></div>
        <h1><?= $esRegistro ? 'Crear cuenta' : 'Sistema CNA' ?></h1>

        <form method="post" autocomplete="on">
            <label for="u">Correo electrónico</label>
            <input id="u" name="u" type="email" maxlength="100" required pattern="[^\s@]+@[^\s@]+\.[^\s@]+" title="Escribe un correo válido que incluya @"
                   value="<?= escapar($_POST['u'] ?? '') ?>">

            <label for="p">Contraseña</label>
            <div class="campo-clave"><input id="p" name="p" type="password" required <?= $esRegistro ? 'minlength="6"' : '' ?> autocomplete="<?= $esRegistro ? 'new-password' : 'current-password' ?>"><button class="mostrar-clave" type="button" data-target="p">Mostrar</button></div>

            <?php if ($esRegistro): ?>
                <label for="p2">Repetir contraseña</label>
                <div class="campo-clave"><input id="p2" name="p2" type="password" required minlength="6" autocomplete="new-password"><button class="mostrar-clave" type="button" data-target="p2">Mostrar</button></div>
                <p class="ayuda">La contraseña debe tener mínimo 6 caracteres, al menos una letra y un número.</p>
                <button type="submit">Registrarme</button>
                <p>¿Ya tienes cuenta? <a href="index.php">Inicia sesión</a></p>
            <?php else: ?>
                <button type="submit">Ingresar</button>
                <p>¿No tienes cuenta? <a href="index.php?registro=1">Regístrate aquí</a></p>
            <?php endif; ?>
        </form>

        <?php if ($mensaje !== ''): ?>
            <p class="mensaje <?= escapar($tipoMensaje) ?>"><?= escapar($mensaje) ?></p>
        <?php endif; ?>
    </main>
    <script>
    (function () {
        const body = document.body;
        const botonTema = document.getElementById('cambiarTema');
        function aplicarTema(tema) {
            body.classList.toggle('tema-oscuro', tema === 'oscuro');
            botonTema.textContent = tema === 'oscuro' ? 'Tema claro' : 'Tema oscuro';
        }
        let temaGuardado = 'claro';
        try { temaGuardado = localStorage.getItem('cna-tema') || 'claro'; } catch (e) {}
        aplicarTema(temaGuardado);
        botonTema.addEventListener('click', function () {
            const tema = body.classList.contains('tema-oscuro') ? 'claro' : 'oscuro';
            aplicarTema(tema);
            try { localStorage.setItem('cna-tema', tema); } catch (e) {}
        });
        document.querySelectorAll('.mostrar-clave').forEach(function (boton) {
            boton.addEventListener('click', function () {
                const campo = document.getElementById(boton.dataset.target);
                const visible = campo.type === 'password';
                campo.type = visible ? 'text' : 'password';
                boton.textContent = visible ? 'Ocultar' : 'Mostrar';
            });
        });
        const formulario = document.querySelector('form');
        formulario.addEventListener('submit', function (evento) {
            const correo = document.getElementById('u');
            if (!correo.value.includes('@') || !correo.checkValidity()) {
                evento.preventDefault();
                correo.setCustomValidity('Ingresa un correo electrónico válido que incluya @.');
                correo.reportValidity();
            } else { correo.setCustomValidity(''); }
            const clave = document.getElementById('p');
            if (<?= $esRegistro ? 'true' : 'false' ?> && (!/[A-Za-z]/.test(clave.value) || !/[0-9]/.test(clave.value))) {
                evento.preventDefault();
                clave.setCustomValidity('La contraseña debe incluir al menos una letra y un número.');
                clave.reportValidity();
            } else { clave.setCustomValidity(''); }
            const repetir = document.getElementById('p2');
            if (repetir && clave.value !== repetir.value) {
                evento.preventDefault();
                repetir.setCustomValidity('Las contraseñas no coinciden.');
                repetir.reportValidity();
            } else if (repetir) { repetir.setCustomValidity(''); }
        });
        document.querySelectorAll('input').forEach(function (campo) {
            campo.addEventListener('input', function () { campo.setCustomValidity(''); });
        });
    })();
    </script>
</body>
</html>
