<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

if (!isset($_SESSION['u'])) {
    header('Location: index.php');
    exit;
}

$postulantes = new Postulante();
$programasEstudios = new ProgramaEstudios();
$inscripciones = new Inscripcion();
$recibos = new Recibo();
$resultados = new Resultado();

$opcionesInscripciones = $inscripciones->opciones(
    "SELECT i.idInscripcion,
            CONCAT(p.dni, ' - ', p.nombres, ' ', p.apellidos)
     FROM inscripciones i
     INNER JOIN postulantes p ON p.idPostulante = i.idPostulante
     ORDER BY i.idInscripcion DESC"
);

$modulos = [
    'postulantes' => [
        'objeto' => $postulantes,
        'titulo' => 'Postulantes',
        'campos' => [
            'dni' => ['DNI', 'text'],
            'nombres' => ['Nombres', 'text'],
            'apellidos' => ['Apellidos', 'text'],
            'fechaNacimiento' => ['Fecha de nacimiento', 'date'],
            'genero' => ['Género', ['Masculino' => 'Masculino', 'Femenino' => 'Femenino', 'Otro' => 'Otro']],
            'correo' => ['Correo electrónico', 'email'],
        ],
    ],
    'programas_estudios' => [
        'objeto' => $programasEstudios,
        'titulo' => 'Programas de estudios',
        'campos' => [
            'nombre' => ['Nombre del programa de estudios', 'text'],
            'estado' => ['Estado', ['Activo' => 'Activo', 'Inactivo' => 'Inactivo']],
        ],
    ],
    'inscripciones' => [
        'objeto' => $inscripciones,
        'titulo' => 'Inscripciones',
        'campos' => [
            'idPostulante' => [
                'Postulante',
                $postulantes->opciones(
                    "SELECT idPostulante, CONCAT(dni, ' - ', nombres, ' ', apellidos)
                     FROM postulantes ORDER BY apellidos, nombres"
                ),
            ],
            'idPrograma' => ['Programa de estudios', $programasEstudios->opciones('SELECT idPrograma, nombre FROM programas_estudios ORDER BY nombre')],
            'periodo' => ['Periodo (ej. 2026-II)', 'text'],
            'fechaInscripcion' => ['Fecha de inscripción', 'date'],
            'estado' => ['Estado', [
                'Registrada' => 'Registrada',
                'Pendiente' => 'Pendiente',
                'Anulada' => 'Anulada',
            ]],
        ],
    ],
    'recibos' => [
        'objeto' => $recibos,
        'titulo' => 'Recibos y pagos',
        'campos' => [
            'idInscripcion' => ['Inscripción', $opcionesInscripciones],
            'numeroRecibo' => ['Número de recibo', 'text'],
            'fechaEmision' => ['Fecha de emisión', 'date'],
            'monto' => ['Monto (S/)', 'number'],
            'concepto' => ['Concepto', 'text'],
            'estado' => ['Estado', ['Pagado' => 'Pagado', 'Pendiente' => 'Pendiente', 'Anulado' => 'Anulado']],
        ],
    ],
    'resultados' => [
        'objeto' => $resultados,
        'titulo' => 'Resultados de exámenes',
        'campos' => [
            'idPostulante' => ['Postulante', $postulantes->opciones("SELECT idPostulante, CONCAT(dni, ' - ', nombres, ' ', apellidos) FROM postulantes ORDER BY apellidos, nombres")],
            'nota1' => ['Nota del examen 1', 'number'],
            'nota2' => ['Nota del examen 2', 'number'],
            'nota3' => ['Nota del examen 3', 'number'],
        ],
    ],
];

$moduloActual = $_GET['m'] ?? 'postulantes';
$idEditar = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$mensajeError = '';
$filas = [];
$formulario = [];
$titulo = '';

try {
    if (isset($_GET['del']) && isset($modulos[$moduloActual])) {
        $idEliminar = filter_input(INPUT_GET, 'del', FILTER_VALIDATE_INT) ?: 0;

        if ($idEliminar > 0) {
            $modulos[$moduloActual]['objeto']->eliminar($idEliminar);
        }

        header('Location: panel.php?m=' . urlencode($moduloActual));
        exit;
    }

    if (isset($modulos[$moduloActual])) {
        $configuracion = $modulos[$moduloActual];
        $objeto = $configuracion['objeto'];
        $titulo = $configuracion['titulo'];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $datos = $_POST;

            $objeto->guardar($datos, $idEditar);
            header('Location: panel.php?m=' . urlencode($moduloActual));
            exit;
        }

        $filas = $objeto->listar();
        $formulario = $idEditar > 0 ? $objeto->buscar($idEditar) : [];
    } elseif ($moduloActual === 'top5') {
        $titulo = 'Reporte: cinco mejores resultados';
        $filas = $resultados->top5();
    } else {
        $mensajeError = 'El módulo solicitado no existe.';
    }
} catch (Throwable $error) {
    $mensajeError = 'No se pudo completar la operación. Verifica los datos y las relaciones. Detalle: '
        . $error->getMessage();
}

function mostrarTabla(array $filas, bool $esTop5, string $moduloActual): void
{
    if ($filas === []) {
        echo '<p>No hay registros para mostrar.</p>';
        return;
    }

    echo '<div class="tabla-contenedor"><table><thead><tr>';

    foreach (array_keys($filas[0]) as $columna) {
        echo '<th>' . escapar($columna) . '</th>';
    }

    if (!$esTop5) {
        echo '<th>Acciones</th>';
    }

    echo '</tr></thead><tbody>';

    foreach ($filas as $fila) {
        echo '<tr>';

        foreach ($fila as $valor) {
            echo '<td>' . escapar($valor) . '</td>';
        }

        if (!$esTop5) {
            $id = (int) reset($fila);
            echo '<td class="acciones">';
            echo '<a href="panel.php?m=' . escapar($moduloActual) . '&id=' . $id . '">Editar</a>';
            echo ' | ';
            echo '<a href="panel.php?m=' . escapar($moduloActual) . '&del=' . $id
                . '" onclick="return confirm(\'¿Seguro que deseas eliminar este registro?\')">Eliminar</a>';
            echo '</td>';
        }

        echo '</tr>';
    }

    echo '</tbody></table></div>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema CNA - Panel</title>
    <link rel="stylesheet" href="css/cna.css">
</head>
<body>
    <header>
        <button class="tema-boton" type="button" id="cambiarTema">Tema oscuro</button>
        <h1>Sistema de Gestión CNA</h1>
        <p>Sesión iniciada como <?= escapar($_SESSION['u']) ?></p>
    </header>

    <nav>
        <?php foreach ($modulos as $clave => $configuracion): ?>
            <a class="<?= $moduloActual === $clave ? 'activo' : '' ?>"
               href="panel.php?m=<?= escapar($clave) ?>">
                <?= escapar($configuracion['titulo']) ?>
            </a>
        <?php endforeach; ?>
        <a class="<?= $moduloActual === 'top5' ? 'activo' : '' ?>" href="panel.php?m=top5">Top 5</a>
        <a class="salir" href="logout.php">Cerrar sesión</a>
    </nav>

    <main>
        <section class="panel">
            <h2><?= escapar($titulo !== '' ? $titulo : 'Panel') ?></h2>

            <?php if ($mensajeError !== ''): ?>
                <p class="error"><?= escapar($mensajeError) ?></p>
            <?php endif; ?>

            <?php if (isset($modulos[$moduloActual])): ?>
                <form method="post">
                    <?php foreach ($modulos[$moduloActual]['campos'] as $campo => $definicion): ?>
                        <?php
                        $etiqueta = $definicion[0];
                        $tipo = $definicion[1] ?? 'text';
                        $valor = $formulario[$campo] ?? '';
                        ?>
                        <div class="campo">
                            <label for="<?= escapar($campo) ?>"><?= escapar($etiqueta) ?></label>

                            <?php if (is_array($tipo)): ?>
                                <select id="<?= escapar($campo) ?>" name="<?= escapar($campo) ?>" required>
                                    <option value="">Selecciona una opción</option>
                                    <?php foreach ($tipo as $valorOpcion => $textoOpcion): ?>
                                        <option value="<?= escapar($valorOpcion) ?>"
                                            <?= (string) $valorOpcion === (string) $valor ? 'selected' : '' ?>>
                                            <?= escapar($textoOpcion) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            <?php elseif ($tipo === 'textarea'): ?>
                                <textarea id="<?= escapar($campo) ?>" name="<?= escapar($campo) ?>"><?= escapar($valor) ?></textarea>
                            <?php else: ?>
                                <input id="<?= escapar($campo) ?>" name="<?= escapar($campo) ?>"
                                       type="<?= escapar((string) $tipo) ?>"
                                       value="<?= escapar($valor) ?>"
                                       <?= in_array($campo, ['nota1', 'nota2', 'nota3', 'monto', 'edad'], true) ? 'step="0.01"' : '' ?>
                                       required>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>

                    <div class="acciones-formulario">
                        <button type="submit"><?= $idEditar > 0 ? 'Actualizar registro' : 'Guardar registro' ?></button>
                        <?php if ($idEditar > 0): ?>
                            <a href="panel.php?m=<?= escapar($moduloActual) ?>">Cancelar edición</a>
                        <?php endif; ?>
                    </div>
                </form>

                <hr class="separador">
                <h3>Registros guardados</h3>
            <?php endif; ?>

            <?php if ($moduloActual === 'top5'): ?>
                <button class="no-imprimir" type="button" onclick="window.print()">Imprimir reporte</button>
            <?php endif; ?>

            <?php mostrarTabla($filas, $moduloActual === 'top5', $moduloActual); ?>
        </section>
    </main>
    <script>
    (function () {
        const body = document.body;
        const boton = document.getElementById('cambiarTema');
        function aplicarTema(tema) {
            body.classList.toggle('tema-oscuro', tema === 'oscuro');
            boton.textContent = tema === 'oscuro' ? 'Tema claro' : 'Tema oscuro';
        }
        let tema = 'claro';
        try { tema = localStorage.getItem('cna-tema') || 'claro'; } catch (e) {}
        aplicarTema(tema);
        boton.addEventListener('click', function () {
            tema = body.classList.contains('tema-oscuro') ? 'claro' : 'oscuro';
            aplicarTema(tema);
            try { localStorage.setItem('cna-tema', tema); } catch (e) {}
        });
    })();
    </script>
</body>
</html>
