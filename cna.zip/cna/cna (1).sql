-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-10-2026 a las 15:56:12
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cna`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coordinadores`
--

CREATE TABLE `coordinadores` (
  `idCoordinador` int(11) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(120) NOT NULL,
  `idPrograma` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `coordinadores`
--

INSERT INTO `coordinadores` (`idCoordinador`, `nombres`, `apellidos`, `correo`, `idPrograma`) VALUES
(1, 'Ana', 'García López', 'coord01@cna.test', 1),
(2, 'Luis', 'Torres Ruiz', 'coord02@cna.test', 2),
(3, 'María', 'Flores Díaz', 'coord03@cna.test', 3),
(4, 'José', 'Rojas Pérez', 'coord04@cna.test', 4),
(5, 'Rosa', 'Vargas León', 'coord05@cna.test', 5),
(6, 'Pedro', 'Sánchez Cruz', 'coord06@cna.test', 6),
(7, 'Elena', 'Castro Silva', 'coord07@cna.test', 7),
(8, 'Carlos', 'Mendoza Ríos', 'coord08@cna.test', 1),
(9, 'Julia', 'Paredes Soto', 'coord09@cna.test', 2),
(10, 'Miguel', 'Ramírez Vega', 'coord10@cna.test', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscripciones`
--

CREATE TABLE `inscripciones` (
  `idInscripcion` int(11) NOT NULL,
  `idPostulante` int(11) NOT NULL,
  `idPrograma` int(11) NOT NULL,
  `fechaInscripcion` date NOT NULL,
  `periodo` varchar(10) NOT NULL,
  `estado` enum('Registrada','Pendiente','Anulada') NOT NULL DEFAULT 'Registrada'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `inscripciones`
--

INSERT INTO `inscripciones` (`idInscripcion`, `idPostulante`, `idPrograma`, `fechaInscripcion`, `periodo`, `estado`) VALUES
(1, 1, 1, '2026-01-10', '2026-I', 'Registrada'),
(2, 2, 2, '2026-01-11', '2026-I', 'Registrada'),
(3, 3, 3, '2026-01-12', '2026-I', 'Registrada'),
(4, 4, 4, '2026-01-13', '2026-I', 'Registrada'),
(5, 5, 5, '2026-01-14', '2026-I', 'Registrada'),
(6, 6, 6, '2026-01-15', '2026-I', 'Registrada'),
(7, 7, 7, '2026-01-16', '2026-I', 'Registrada'),
(8, 8, 1, '2026-01-17', '2026-I', 'Registrada'),
(9, 9, 2, '2026-01-18', '2026-I', 'Registrada'),
(10, 10, 3, '2026-01-19', '2026-I', 'Registrada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `postulantes`
--

CREATE TABLE `postulantes` (
  `idPostulante` int(11) NOT NULL,
  `dni` char(8) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `genero` enum('Masculino','Femenino','Otro') NOT NULL,
  `correo` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `postulantes`
--

INSERT INTO `postulantes` (`idPostulante`, `dni`, `nombres`, `apellidos`, `fechaNacimiento`, `genero`, `correo`) VALUES
(1, '70000001', 'Juan', 'Pérez López', '2005-01-15', 'Masculino', 'post01@cna.test'),
(2, '70000002', 'María', 'García Torres', '2005-03-20', 'Femenino', 'post02@cna.test'),
(3, '70000003', 'Carlos', 'Flores Ruiz', '2004-06-10', 'Masculino', 'post03@cna.test'),
(4, '70000004', 'Ana', 'Rojas Díaz', '2005-08-12', 'Femenino', 'post04@cna.test'),
(5, '70000005', 'Luis', 'Vargas León', '2004-11-25', 'Masculino', 'post05@cna.test'),
(6, '70000006', 'Rosa', 'Sánchez Cruz', '2005-02-08', 'Femenino', 'post06@cna.test'),
(7, '70000007', 'Pedro', 'Castro Silva', '2004-04-17', 'Masculino', 'post07@cna.test'),
(8, '70000008', 'Elena', 'Mendoza Ríos', '2005-07-09', 'Femenino', 'post08@cna.test'),
(9, '70000009', 'José', 'Paredes Soto', '2004-09-30', 'Masculino', 'post09@cna.test'),
(10, '70000010', 'Julia', 'Ramírez Vega', '2005-12-01', 'Femenino', 'post10@cna.test');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `programas_estudios`
--

CREATE TABLE `programas_estudios` (
  `idPrograma` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estado` enum('Activo','Inactivo') NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `programas_estudios`
--

INSERT INTO `programas_estudios` (`idPrograma`, `nombre`, `estado`) VALUES
(1, 'Enfermería', 'Activo'),
(2, 'Industria Alimentaria', 'Activo'),
(3, 'Mecatrónica', 'Activo'),
(4, 'Agropecuaria', 'Activo'),
(5, 'Administración', 'Activo'),
(6, 'APSTI', 'Activo'),
(7, 'Computación e Informática', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recibos`
--

CREATE TABLE `recibos` (
  `idRecibo` int(11) NOT NULL,
  `idInscripcion` int(11) NOT NULL,
  `numeroRecibo` varchar(20) NOT NULL,
  `fechaEmision` date NOT NULL,
  `monto` decimal(10,2) NOT NULL DEFAULT 0.00,
  `concepto` varchar(100) NOT NULL,
  `estado` enum('Pagado','Pendiente','Anulado') NOT NULL DEFAULT 'Pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `recibos`
--

INSERT INTO `recibos` (`idRecibo`, `idInscripcion`, `numeroRecibo`, `fechaEmision`, `monto`, `concepto`, `estado`) VALUES
(1, 1, 'CNA-0001', '2026-01-10', 150.00, 'Inscripción', 'Pagado'),
(2, 2, 'CNA-0002', '2026-01-11', 150.00, 'Inscripción', 'Pagado'),
(3, 3, 'CNA-0003', '2026-01-12', 150.00, 'Inscripción', 'Pagado'),
(4, 4, 'CNA-0004', '2026-01-13', 150.00, 'Inscripción', 'Pendiente'),
(5, 5, 'CNA-0005', '2026-01-14', 150.00, 'Inscripción', 'Pagado'),
(6, 6, 'CNA-0006', '2026-01-15', 150.00, 'Inscripción', 'Pendiente'),
(7, 7, 'CNA-0007', '2026-01-16', 150.00, 'Inscripción', 'Pagado'),
(8, 8, 'CNA-0008', '2026-01-17', 150.00, 'Inscripción', 'Pagado'),
(9, 9, 'CNA-0009', '2026-01-18', 150.00, 'Inscripción', 'Pendiente'),
(10, 10, 'CNA-0010', '2026-01-19', 150.00, 'Inscripción', 'Pagado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultados`
--

CREATE TABLE `resultados` (
  `idResultado` int(11) NOT NULL,
  `idPostulante` int(11) NOT NULL,
  `nota1` decimal(5,2) NOT NULL,
  `nota2` decimal(5,2) NOT NULL,
  `nota3` decimal(5,2) NOT NULL,
  `promedio` decimal(5,2) GENERATED ALWAYS AS ((`nota1` + `nota2` + `nota3`) / 3) STORED,
  `puesto` int(11) DEFAULT NULL
) ;

--
-- Volcado de datos para la tabla `resultados`
--

INSERT INTO `resultados` (`idResultado`, `idPostulante`, `nota1`, `nota2`, `nota3`, `puesto`) VALUES
(1, 1, 19.00, 18.00, 20.00, 1),
(2, 2, 18.00, 18.00, 19.00, 2),
(3, 3, 17.00, 18.00, 18.00, 3),
(4, 4, 17.00, 17.00, 18.00, 4),
(5, 5, 16.00, 17.00, 17.00, 5),
(6, 6, 16.00, 16.00, 17.00, 6),
(7, 7, 15.00, 16.00, 16.00, 7),
(8, 8, 15.00, 15.00, 16.00, 8),
(9, 9, 14.00, 15.00, 15.00, 9),
(10, 10, 14.00, 14.00, 15.00, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idUsuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(120) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','coordinador','usuario') NOT NULL DEFAULT 'usuario',
  `estado` enum('Activo','Inactivo') NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idUsuario`, `nombre`, `correo`, `password`, `rol`, `estado`) VALUES
(1, 'Administrador', 'admin@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Activo'),
(2, 'Usuario 02', 'usuario02@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(3, 'Usuario 03', 'usuario03@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(4, 'Usuario 04', 'usuario04@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(5, 'Usuario 05', 'usuario05@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(6, 'Usuario 06', 'usuario06@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(7, 'Usuario 07', 'usuario07@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(8, 'Usuario 08', 'usuario08@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(9, 'Usuario 09', 'usuario09@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo'),
(10, 'Usuario 10', 'usuario10@cna.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'usuario', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `coordinadores`
--
ALTER TABLE `coordinadores`
  ADD PRIMARY KEY (`idCoordinador`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `idPrograma` (`idPrograma`);

--
-- Indices de la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  ADD PRIMARY KEY (`idInscripcion`),
  ADD UNIQUE KEY `idPostulante` (`idPostulante`,`periodo`),
  ADD KEY `idPrograma` (`idPrograma`);

--
-- Indices de la tabla `postulantes`
--
ALTER TABLE `postulantes`
  ADD PRIMARY KEY (`idPostulante`),
  ADD UNIQUE KEY `dni` (`dni`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `programas_estudios`
--
ALTER TABLE `programas_estudios`
  ADD PRIMARY KEY (`idPrograma`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `recibos`
--
ALTER TABLE `recibos`
  ADD PRIMARY KEY (`idRecibo`),
  ADD UNIQUE KEY `numeroRecibo` (`numeroRecibo`),
  ADD KEY `idInscripcion` (`idInscripcion`);

--
-- Indices de la tabla `resultados`
--
ALTER TABLE `resultados`
  ADD PRIMARY KEY (`idResultado`),
  ADD UNIQUE KEY `idPostulante` (`idPostulante`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `coordinadores`
--
ALTER TABLE `coordinadores`
  MODIFY `idCoordinador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  MODIFY `idInscripcion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `postulantes`
--
ALTER TABLE `postulantes`
  MODIFY `idPostulante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `programas_estudios`
--
ALTER TABLE `programas_estudios`
  MODIFY `idPrograma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `recibos`
--
ALTER TABLE `recibos`
  MODIFY `idRecibo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `resultados`
--
ALTER TABLE `resultados`
  MODIFY `idResultado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `coordinadores`
--
ALTER TABLE `coordinadores`
  ADD CONSTRAINT `coordinadores_ibfk_1` FOREIGN KEY (`idPrograma`) REFERENCES `programas_estudios` (`idPrograma`);

--
-- Filtros para la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  ADD CONSTRAINT `inscripciones_ibfk_1` FOREIGN KEY (`idPostulante`) REFERENCES `postulantes` (`idPostulante`),
  ADD CONSTRAINT `inscripciones_ibfk_2` FOREIGN KEY (`idPrograma`) REFERENCES `programas_estudios` (`idPrograma`);

--
-- Filtros para la tabla `recibos`
--
ALTER TABLE `recibos`
  ADD CONSTRAINT `recibos_ibfk_1` FOREIGN KEY (`idInscripcion`) REFERENCES `inscripciones` (`idInscripcion`);

--
-- Filtros para la tabla `resultados`
--
ALTER TABLE `resultados`
  ADD CONSTRAINT `resultados_ibfk_1` FOREIGN KEY (`idPostulante`) REFERENCES `postulantes` (`idPostulante`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
