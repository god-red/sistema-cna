<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/models/Usuario.php';
require_once __DIR__ . '/models/Coordinador.php';
require_once __DIR__ . '/models/Postulante.php';
require_once __DIR__ . '/models/ProgramaEstudios.php';
require_once __DIR__ . '/models/Inscripcion.php';
require_once __DIR__ . '/models/Recibo.php';
require_once __DIR__ . '/models/Resultado.php';

function escapar(mixed $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
