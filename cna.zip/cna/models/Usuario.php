<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class Usuario extends Modelo
{
    public function __construct()
    {
        parent::__construct('usuarios', 'idUsuario', ['nombre', 'correo', 'password', 'rol', 'estado']);
    }
    public function registrar(string $correo, string $contrasena): void
    {
        $correo = trim($correo);
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Ingresa un correo electrónico válido.');
        if (strlen($contrasena) < 8) throw new InvalidArgumentException('La contraseña debe tener al menos 8 caracteres.');
        if (!preg_match('/[a-z]/', $contrasena) || !preg_match('/[A-Z]/', $contrasena)) throw new InvalidArgumentException('La contraseña debe incluir mayúscula y minúscula.');
        if (!preg_match('/[0-9]/', $contrasena)) throw new InvalidArgumentException('La contraseña debe incluir al menos un número.');
        $this->guardar([
            'nombre' => $correo,
            'correo' => $correo,
            'password' => password_hash($contrasena, PASSWORD_DEFAULT),
            'rol' => 'usuario',
            'estado' => 'Activo'
        ]);
    }
    public function login(string $correo, string $contrasena): array|false
    {
        if (trim($correo) === '' || $contrasena === '') return false;
        $stmt = Database::getConnection()->prepare("SELECT * FROM usuarios WHERE correo = :correo AND estado = 'Activo' LIMIT 1");
        $stmt->execute(['correo'=>trim($correo)]);
        $registro = $stmt->fetch();
        return ($registro && password_verify($contrasena, $registro['password'])) ? $registro : false;
    }
}
