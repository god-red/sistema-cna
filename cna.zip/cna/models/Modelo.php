<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/Database.php';

/**
 * Clase abstracta con operaciones CRUD comunes.
 * Las clases hijas definen la tabla, su clave primaria y los campos permitidos.
 */
abstract class Modelo
{
    protected string $tabla;
    protected string $clavePrimaria;
    protected array $camposPermitidos;
    protected ?string $consultaListado;

    public function __construct(
        string $tabla,
        string $clavePrimaria,
        array $camposPermitidos,
        ?string $consultaListado = null
    ) {
        $this->tabla = $tabla;
        $this->clavePrimaria = $clavePrimaria;
        $this->camposPermitidos = $camposPermitidos;
        $this->consultaListado = $consultaListado;
    }

    public function listar(): array
    {
        $sql = $this->consultaListado ?? "SELECT * FROM {$this->tabla}";
        return Database::getConnection()->query($sql)->fetchAll();
    }

    public function buscar(int $id): array
    {
        $sql = "SELECT * FROM {$this->tabla} WHERE {$this->clavePrimaria} = :id";
        $sentencia = Database::getConnection()->prepare($sql);
        $sentencia->execute(['id' => $id]);

        return $sentencia->fetch() ?: [];
    }

    public function opciones(string $sql): array
    {
        return Database::getConnection()
            ->query($sql)
            ->fetchAll(PDO::FETCH_KEY_PAIR);
    }

    public function guardar(array $datos, int $id = 0): void
    {
        $datos = array_intersect_key(
            $datos,
            array_flip($this->camposPermitidos)
        );

        if ($datos === []) {
            throw new InvalidArgumentException('No hay campos válidos para guardar.');
        }

        if ($id > 0) {
            $asignaciones = [];

            foreach (array_keys($datos) as $campo) {
                $asignaciones[] = "{$campo} = :{$campo}";
            }

            $sql = "UPDATE {$this->tabla} SET "
                . implode(', ', $asignaciones)
                . " WHERE {$this->clavePrimaria} = :id";

            $datos['id'] = $id;
        } else {
            $campos = array_keys($datos);
            $marcadores = array_map(
                static fn(string $campo): string => ':' . $campo,
                $campos
            );

            $sql = "INSERT INTO {$this->tabla} ("
                . implode(', ', $campos)
                . ') VALUES ('
                . implode(', ', $marcadores)
                . ')';
        }

        $sentencia = Database::getConnection()->prepare($sql);
        $sentencia->execute($datos);
    }

    public function eliminar(int $id): void
    {
        $sql = "DELETE FROM {$this->tabla} WHERE {$this->clavePrimaria} = :id";
        $sentencia = Database::getConnection()->prepare($sql);
        $sentencia->execute(['id' => $id]);
    }

    public function getTabla(): string
    {
        return $this->tabla;
    }

    public function getClavePrimaria(): string
    {
        return $this->clavePrimaria;
    }
}
