<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class Resultado extends Modelo
{
    public function __construct()
    {
        $consulta = "SELECT r.idResultado, CONCAT(p.nombres, ' ', p.apellidos) AS postulante,
                            r.nota1, r.nota2, r.nota3, r.promedio, r.puesto
                     FROM resultados r
                     INNER JOIN postulantes p ON p.idPostulante = r.idPostulante
                     ORDER BY r.puesto ASC";
        parent::__construct('resultados', 'idResultado',
            ['idPostulante', 'nota1', 'nota2', 'nota3'], $consulta);
    }
    public function guardar(array $datos, int $id = 0): void
    {
        foreach (['nota1','nota2','nota3'] as $campo) {
            if (!isset($datos[$campo]) || !is_numeric($datos[$campo])) throw new InvalidArgumentException('Ingresa las tres notas.');
            $nota = (float)$datos[$campo];
            if ($nota < 0 || $nota > 20) throw new InvalidArgumentException('Cada nota debe estar entre 0 y 20.');
            $datos[$campo] = $nota;
        }
        // promedio es una columna generada por MySQL; no se inserta manualmente.
        unset($datos['promedio'], $datos['puesto']);
        parent::guardar($datos, $id);
        $this->recalcularPuestos();
    }
    public function eliminar(int $id): void { parent::eliminar($id); $this->recalcularPuestos(); }
    private function recalcularPuestos(): void
    {
        $ids = Database::getConnection()->query('SELECT idResultado FROM resultados ORDER BY promedio DESC, idResultado ASC')->fetchAll();
        $stmt = Database::getConnection()->prepare('UPDATE resultados SET puesto = :puesto WHERE idResultado = :id');
        foreach ($ids as $i => $fila) $stmt->execute(['puesto'=>$i+1, 'id'=>$fila['idResultado']]);
    }
    public function top5(): array { return array_slice($this->listar(), 0, 5); }
}
