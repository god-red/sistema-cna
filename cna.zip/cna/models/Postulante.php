<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class Postulante extends Modelo
{
    private string $dni = '';
    private string $nombres = '';
    private string $apellidos = '';
    private string $fechaNacimiento = '';
    private string $genero = 'Masculino';
    private string $correo = '';

    public function __construct()
    {
        parent::__construct('postulantes', 'idPostulante',
            ['dni', 'nombres', 'apellidos', 'fechaNacimiento', 'genero', 'correo']);
    }
    public function getDni(): string { return $this->dni; }
    public function setDni(string $dni): void {
        $dni = trim($dni);
        if (!preg_match('/^[0-9]{8}$/', $dni)) throw new InvalidArgumentException('El DNI debe tener 8 dígitos.');
        $this->dni = $dni;
    }
    public function getNombres(): string { return $this->nombres; }
    public function setNombres(string $v): void { $this->nombres = trim($v); }
    public function getApellidos(): string { return $this->apellidos; }
    public function setApellidos(string $v): void { $this->apellidos = trim($v); }
    public function getFechaNacimiento(): string { return $this->fechaNacimiento; }
    public function setFechaNacimiento(string $v): void { $this->fechaNacimiento = trim($v); }
    public function getGenero(): string { return $this->genero; }
    public function setGenero(string $v): void {
        if (!in_array($v, ['Masculino','Femenino','Otro'], true)) throw new InvalidArgumentException('Género no válido.');
        $this->genero = $v;
    }
    public function getCorreo(): string { return $this->correo; }
    public function setCorreo(string $v): void {
        $v = trim($v);
        if (!filter_var($v, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('El correo no es válido.');
        $this->correo = $v;
    }
}
