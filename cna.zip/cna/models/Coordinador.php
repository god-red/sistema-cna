<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class Coordinador extends Modelo
{
    public function __construct()
    {
        parent::__construct('coordinadores', 'idCoordinador', ['nombres', 'apellidos', 'correo', 'idPrograma']);
    }
    public function idPorUsuario(int $idUsuario): ?int
    {
        // El esquema SQL actual no relaciona coordinadores con usuarios.
        return null;
    }
}
