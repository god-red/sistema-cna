<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class Inscripcion extends Modelo
{
    public function __construct()
    {
        $consulta = "SELECT i.idInscripcion, CONCAT(p.dni, ' - ', p.nombres, ' ', p.apellidos) AS postulante,
                            pe.nombre AS programa_estudios, i.fechaInscripcion, i.periodo, i.estado
                     FROM inscripciones i
                     INNER JOIN postulantes p ON p.idPostulante = i.idPostulante
                     INNER JOIN programas_estudios pe ON pe.idPrograma = i.idPrograma
                     ORDER BY i.idInscripcion DESC";
        parent::__construct('inscripciones', 'idInscripcion',
            ['idPostulante', 'idPrograma', 'fechaInscripcion', 'periodo', 'estado'], $consulta);
    }
}
