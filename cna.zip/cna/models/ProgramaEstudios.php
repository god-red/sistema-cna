<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class ProgramaEstudios extends Modelo
{
    private string $nombre = '';
    private string $estado = 'Activo';

    public function __construct()
    {
        parent::__construct('programas_estudios', 'idPrograma', ['nombre', 'estado']);
    }
    public function getNombre(): string { return $this->nombre; }
    public function setNombre(string $v): void { $this->nombre = trim($v); }
    public function getEstado(): string { return $this->estado; }
    public function setEstado(string $v): void {
        if (!in_array($v, ['Activo','Inactivo'], true)) throw new InvalidArgumentException('Estado no válido.');
        $this->estado = $v;
    }
}
