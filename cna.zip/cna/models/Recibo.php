<?php
declare(strict_types=1);
require_once __DIR__ . '/Modelo.php';

class Recibo extends Modelo
{
    public function __construct()
    {
        $consulta = "SELECT r.idRecibo, r.idInscripcion, r.numeroRecibo, r.fechaEmision, r.monto, r.concepto, r.estado
                     FROM recibos r ORDER BY r.idRecibo DESC";
        parent::__construct('recibos', 'idRecibo',
            ['idInscripcion', 'numeroRecibo', 'fechaEmision', 'monto', 'concepto', 'estado'], $consulta);
    }
}
